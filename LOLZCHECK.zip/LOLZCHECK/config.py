token_tg = 'TG Bot Token'
token_lolz = 'LZT Public API Token'
