from aiogram import Bot, types, Dispatcher, F, Router
import logging, asyncio
from config import token_tg
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
router = Router()
dp = Dispatcher(storage=MemoryStorage())
bot = Bot(token=token_tg, parse_mode=ParseMode.HTML)



async def main():
    from lolztg import router
    dp.include_router(router)
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    loop = asyncio.get_event_loop()
    asyncio.run(main())