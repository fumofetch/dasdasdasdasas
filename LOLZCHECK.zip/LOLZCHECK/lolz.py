import aiohttp
import asyncio
from config import token_lolz
from tenacity import retry, stop_after_attempt, wait_fixed

headers = {
    'accept': 'application/json',
    'Authorization': f'Bearer {token_lolz}',
}

@retry(stop=stop_after_attempt(9999), reraise=True, wait=wait_fixed(1))
async def getinfobatch(tgname):
    url = 'https://api.zelenka.guru/users/find'

    params = {
        'custom_fields[telegram]': f'{tgname}',
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params, headers=headers) as response:
            data = await response.json()

    return data['users']

@retry(stop=stop_after_attempt(9999), reraise=True, wait=wait_fixed(1))
async def getcontentsbatch(user_id):
    url = 'https://api.zelenka.guru/threads'

    params = {
        'forum_id': '771',
        'creator_user_id': f'{user_id}',
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params, headers=headers) as response:
            data = await response.json()

    return data['threads_total']
