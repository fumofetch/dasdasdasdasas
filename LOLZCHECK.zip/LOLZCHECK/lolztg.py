import hashlib, logging, aiohttp, lolz
from datetime import timedelta, datetime
from aiogram import types
from LOLZCHECKER import Bot, router
from aiogram.types import InlineQueryResultArticle, InputTextMessageContent
from aiogram.filters import CommandStart


group_mapping = {
    1: 'Гость',
    2: 'Зарегистрирован',
    3: 'Администратор',
    4: 'Модератор',
    7: 'Разработчик',
    8: 'Суприм',
    9: 'Дизайнер',
    11: 'Продавец',
    12: 'Главный модератор',
    18: '20 баллов',
    21: 'Местный',
    22: 'Постоялец',
    23: 'Эксперт',
    26: 'Легенда',
    29: 'Куратор',
    30: 'Арбитр',
    32: 'Бот',
    38: 'Антипаблик',
    41: 'Доступ к маркету',
    60: 'Гуру',
    65: 'Привилегии на маркете',
    142: 'Read Only',
    166: 'Табличка Scam',
    265: 'Уник',
    349: 'Редактор',
    350: 'Главный дизайнер',
    351: 'Искусственный интеллект',
    353: 'Главный арбитр',
    354: 'Рекламный менеджер',
    359: 'Спонсор',
    360: 'Обжалование бана',
    361: 'Команда Гарант бота',
}





def EpochTimeToStr(timestamp, *, round_ = 6):
    s = (datetime.utcfromtimestamp(timestamp)) + timedelta(hours=3)
    s = s.strftime('%d.%m.%Y %H:%M:%S')
    return s


def format(userdata):
    try:
        scamHTML = userdata[0]['username_html'] if "username_html" in userdata[0] else 0
        if "scamNotice" in scamHTML:
            scamHTML = 1
        else:
            scamHTML = 0
            user_id = userdata[0]["user_id"]
            #await asyncio.sleep(3)
            #user_contests = await lolz.getcontentsbatch(user_id)
            try:
                if len(user_contests) == 0:
                    user_contests = 0
            except:
                pass

            ban_reason = userdata[0]['custom_fields'].get('ban_reason')

            fields = ""

            avatar = userdata[0]['links'].get('avatar')

            telegram = userdata[0]['custom_fields'].get('telegram')
            if telegram is not None and telegram != "":
                fields += f'<b>💬 Telegram:</b> <a href="t.me/{telegram}">{telegram}</a>\n'

            vk = userdata[0]['custom_fields'].get('vk')
            if vk is not None and vk != "":
                fields += f"<b>🌐 ВКонтакте:</b> <a href='{vk}'>Ссылка</a>\n"

            steam = userdata[0]['custom_fields'].get('steam')
            if steam is not None and steam != "":
                fields += f"<b>🎮 Steam:</b> <a href='{steam}'>Ссылка</a>\n"

            discord = userdata[0]['custom_fields'].get('discord')
            if discord is not None and discord != "":
                fields += f"<b>🎤 Discord:</b> {discord}\n"

            jabber = userdata[0]['custom_fields'].get('jabber')
            if jabber is not None and jabber != "":
                fields += f"<b>📎 Jabber:</b> {jabber}\n"

            lztDeposit = userdata[0]['custom_fields'].get('lztDeposit')
            if lztDeposit is not None and lztDeposit != "":
                lztDeposit = f"\n<b>💰 Депозит:</b> {lztDeposit} ₽"
            else:
                lztDeposit = f"\n<b>💰 Депозит:</b> 0 ₽"

            if fields:
                fields = "\n" + fields

            if fields.endswith("\n"):
                fields = fields[:-1]

            user_group_id = userdata[0]['user_group_id']
            group_text = group_mapping.get(user_group_id, str(user_group_id))

            message_text = f'''
<b>👤 Профиль LZT:<a href="{avatar}"> </a></b><a href="https://zelenka.guru/members/{userdata[0]['user_id']}/">{userdata[0]['username']}</a>{fields}
<b>ℹ️ Активная группа:</b> {group_text}
<b>📝 Статус:</b> {userdata[0]['user_title']}
<b>✉️ Сообщений:</b> {userdata[0]['user_message_count']}
<b>💚 Симпатий:</b> {userdata[0]['user_like_count']}{lztDeposit}
<b>📅 Дата регистрации:</b> {EpochTimeToStr(userdata[0]['user_register_date'])}
<b>🚫 SCAM-Табличка:</b> {'Есть' if scamHTML or userdata[0]['custom_fields'].get('scamURL') else 'Нет'}
<b>🔒 Заблокирован:</b> {ban_reason if ban_reason else 'Нет'}

'''
            return message_text
    except Exception as e:
        logging.exception(e)
        return None
@router.inline_query(lambda query: len(query.query) > 0 and "." not in query.query[0])
async def inlinequery_lolz(inline_query: types.InlineQuery, bot: Bot):
    query = (inline_query.query).replace("@", "").replace("https://t.me/", "").replace("http://t.me/", "")
    if not query:
        return
    try:
        userdata = await lolz.getinfobatch(query)
        result_id: str = hashlib.md5(query.encode()).hexdigest()

        if userdata:
            message_text = format(userdata)
            content = InputTextMessageContent(message_text=str(message_text))

            result = InlineQueryResultArticle(
                id=result_id,
                title=userdata[0]['username'],
                thumb_url=userdata[0]['links']['avatar'],
                description=userdata[0]['user_title'],
                input_message_content=content, parse_mode='HTML'
            )
            await bot.answer_inline_query(inline_query.id, results=[result], cache_time=3)
        else:
            content_except = InputTextMessageContent(message_text=str('Такого юзера нет.'))
            result = InlineQueryResultArticle(
                id=result_id,
                title='Пользователь не найден',
                input_message_content=content_except
            )
            await bot.answer_inline_query(inline_query.id, results=[result], cache_time=3)
    except Exception as e:
        logging.exception(e)

async def get_api_response(query_text):
    url = "https://api.futureforge.dev/claude-instant/create"
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
    }
    data = {
        "message": query_text
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, json=data) as response:
            if response.status == 200:
                response_data = await response.json()
                response_text = response_data.get("message", "")
                return response_text
            else:
                return "Ошибка при получении ответа от API"


@router.inline_query(lambda query: query.query.startswith('.'))
async def first_inline_query_handler(query: types.InlineQuery):
    query_text = query.query.replace('.', '', 1).strip()
    query_text = query_text.lstrip('.').strip()  
    if query_text:
        response = await get_api_response(query_text)
        result_id = query.id
        title = "Ответ от ИИ"
        description = response
        text = f"<b>Ваш запрос:</b>\n {query_text}\n<b>Ответ от ИИ:</b>\n{description}"
        input_message_content = InputTextMessageContent(message_text=str(text))
        result = InlineQueryResultArticle(
            id=result_id,
            title=title,
            description=description,
            input_message_content=input_message_content
        )

        await query.answer(results=[result], cache_time=1)
@router.message(CommandStart)
async def start_cmd(msg: types.Message):
    await msg.reply("""
<b>Что бы использовать парсер, вводите в любом чате:</b>
<code>@erlolzbot юзернейм</code>
<code>@erlolzbot @юзернейм</code>
<code>@erlolzbot https://t.me/юзернейм</code>

<b>Что бы использовать ИИ, вводите в любом чате:</b>
<code>@erlolzbot . Запрос</code>""")
